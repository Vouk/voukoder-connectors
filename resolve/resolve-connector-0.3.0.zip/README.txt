Installation
------------
1. Extract the contents of this zip file to %ProgramData%\Blackmagic Design\DaVinci Resolve\Support\IOPlugins
2. Make sure you have the main Voukoder application installed
3. Done

Updates and support
-------------------
You can find new versions and support at www.voukoder.org.


Support the project
-------------------
If you like this project please consider supporting it at:

- https://www.patreon.com/voukoder
- https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=S6LGDW9QZYBTL&source=url


Thanks,
Daniel